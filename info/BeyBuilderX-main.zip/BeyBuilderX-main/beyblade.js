/*==========================================================*
 * BeyBuilder v2.0 for Beyblade X                           *
 * Author: Fabel                                            *
 * Copyright 2023-2026                                      *
 *==========================================================*/

var allBlades = blades;
var allRachets = rachets;
var allBits = bits;

class BeyBlade {

    bitChip = -1;
    over = -1; 
    blade = -1;
    assist = -1; 
    rachet = -1;
    bit = -1;
    id = ""; // DB index, a string
    name = "";
    weight = 0;
    height = 0;
    spin = "invalid";
    system = "invalid"; 
    totalWins = 0;
    winsKO = 0;
    winsSO = 0;
    winsBst = 0;
    winsX = 0;
    totalLosses = 0;
    loseKO = 0;
    loseSO = 0;
    loseBst = 0;
    loseX = 0;
    draws = 0;
    totalMatches = 0;

    constructor(bitChip, over, blade, assist, rachet, bit){
        /*
        console.log("building bey with parts: " +
                    "bitChip: " + bitChip + ", " +
                    "over: " + over + ", " +
                    "blade: " + blade + ", " +
                    "assist: " + assist + ", " +
                    "rachet: " + rachet + ", " +
                    "bit: " + bit
                );
        */

        this.bitChip = bitChip;
        this.over = over;
        this.blade = blade;
        this.assist = assist; 
        this.rachet = rachet;
        this.bit = bit;
        this.system = allBlades[this.blade].system;

        // start weight. Add more later depending on parts selected
        this.weight = allBlades[this.blade].weight + allBits[this.bit].weight;

        if(allBits[this.bit].type == "ratchetBit" || allBlades[this.blade].system == "UX2") { // combo bit and ratchet or combo blade ratchet
            console.log("disabling ratchets")
            this.rachet = -1;
        }
        
        if (this.rachet != -1) {
            // regular ratchet
            this.weight += allRachets[this.rachet].weight;
        }

        if(this.system == "CX") {
            this.weight += allBitChips[this.bitChip].weight + allAssists[this.assist].weight;
        } else if(this.system == "CX2") {
            this.weight += allBitChips[this.bitChip].weight + allOverBlades[this.over].weight + allAssists[this.assist].weight;
        } else { // BX or UX
            this.bitChip = -1;
            this.over = -1;
            this.assist = -1;
        }

        this.id = this.getDbId();
        this.name = this.findName();
        this.findSpin();
    }


    //are these necessary?
    getBlade(){
        return this.blade;
    }
    getRachet(){
        return this.rachet;
    }
    getBit(){
        return this.bit;
    }
    getName(){
        return this.name;
    }
    getId(){
        return this.id;
    }
    getWeight(){
        return this.weight;
    }
    getSpin(){
        return this.spin;
    }
    getDBid(){
        return this.id;
    }
    getTotalWin(){
        this.totalWins =  this.winsBst + this.winsKO + this.winsSO + this.winsX;
        return this.totalWins;
    }
    getTotalLoss(){
        this.totalLosses = this.loseBst + this.loseKO + this.loseSO + this.loseX;
        return this.totalLosses;
    }
    getTotalMatch(){
        this.totalMatches =  this.getTotalWin() + this.getTotalLoss() + this.draws;
        return this.totalMatches;
    }
    getWinPoints(){
        return (this.winsBst * 2) + (this.winsKO * 2) + this.winsSO + (this.winsX * 3);
    }
    getLossPoints(){
        return (this.loseBst * 2) + (this.loseKO * 2) + this.loseSO + (this.loseX * 3);
    }
    getPointChange(){
        return (this.winsKO - this.loseKO) * 2
            + (this.winsSO - this.loseSO)
            + (this.winsBst - this.loseBst) * 2
            + (this.winsX - this.loseX) * 3;
    }
    findSpin(){
        this.spin = allBlades[this.blade].spin;
    }

    /**
     * generate full beyblade name, blade ratchet bit
     * @returns {string} name
     */
    findName(){
        var newName = "";

        var ratchetNameInclSpaces = " ";
        if(this.rachet>-1) {
            // regular ratchet
            ratchetNameInclSpaces += allRachets[this.rachet].name + " ";
        }

        if((this.system == "BX") || (this.system == "BX2") || (this.system == "UX")){
            newName = allBlades[this.blade].name + ratchetNameInclSpaces + allBits[this.bit].name;
        }
        else if(this.system == "UX2"){
            newName = allBlades[this.blade].name + " " + allBits[this.bit].name;
        }
        else if(this.system == "CX"){
            newName = allBitChips[this.bitChip].name + allBlades[this.blade].name + " " + allAssists[this.assist].name + ratchetNameInclSpaces + allBits[this.bit].name;
        }
        else if(this.system == "CX2"){
            newName = allBitChips[this.bitChip].name + allBlades[this.blade].name + " " + allOverBlades[this.over].name + " " + allAssists[this.assist].name + ratchetNameInclSpaces + allBits[this.bit].name;
        }

        return newName;
    }

    /**
     * generate full beyblade name with <span> tags to help style and line-break
     * @returns {string} name as HTML
     */
    findNameHtml(){
        var bladeText = "";
        var tailText = "";

        var ratchetNameInclSpaces = "";
        if(this.rachet>-1) {
            // regular ratchet
            ratchetNameInclSpaces += allRachets[this.rachet].name + " ";
        }

        if((this.system == "BX") || (this.system == "BX2") || (this.system == "UX")){
            bladeText = allBlades[this.blade].name;
            tailText = ratchetNameInclSpaces + allBits[this.bit].name;
        }
        else if(this.system == "UX2"){
            bladeText = allBlades[this.blade].name + " " + allBits[this.bit].name;
        }
        else if(this.system == "CX"){
            bladeText = allBitChips[this.bitChip].name + allBlades[this.blade].name + " " + allAssists[this.assist].name;
            tailText = ratchetNameInclSpaces + allBits[this.bit].name;
        }
        else if(this.system == "CX2"){
            bladeText = allBitChips[this.bitChip].name + allBlades[this.blade].name + " " + allOverBlades[this.over].name + " " + allAssists[this.assist].name;
            tailText = ratchetNameInclSpaces + allBits[this.bit].name;
        }

        var newName = `<span class="blade-text">` + bladeText + `</span>`;
        if(tailText){
            // split at the ratchet so the name can wrap
            newName += `<span class="blade-text">&nbsp;` + tailText + `</span>`;
        }
        return newName;
    }

    // construct beyblade ID string
    getDbId(){
        return ( (this.system=="CX" || this.system=="CX2") ? allBitChips[this.bitChip].id + " " : "" ) + // if CX, add bitChip name + space
                    ( this.system=="CX2" ? allOverBlades[this.over].id + " " : "" ) + // if CX2, add overBlade name + space
                    allBlades[this.blade].id + " " +
                    ( (this.system=="CX" || this.system=="CX2") ? allAssists[this.assist].id + " " : "" ) + // if CX, add assistBlade name + space
                    ( this.rachet==-1 ? "" : allRachets[this.rachet].id + " " ) + // if no ratchet, blank, else ratchet name + space
                    allBits[this.bit].id ;
    }

    /**
     * Build a BeyBlade from a stored build, preserving win/loss fields.
     * @param {object} build
     * @returns {BeyBlade}
     */
    static fromBuild(build) {
        if (!build || build.blade == null) {
            return Object.assign(new BeyBlade(-1, -1, 0, -1, -1, 0), build || {});
        }
        var system = allBlades[build.blade].system;
        if (system === "BX" || system === "BX2" || system === "UX") {
            return Object.assign(new BeyBlade(-1, -1, build.blade, -1, build.rachet, build.bit), build);
        }
        if (system === "UX2") {
            return Object.assign(new BeyBlade(-1, -1, build.blade, -1, -1, build.bit), build);
        }
        if (system === "CX") {
            return Object.assign(new BeyBlade(build.bitChip, -1, build.blade, build.assist, build.rachet, build.bit), build);
        }
        if (system === "CX2") {
            return Object.assign(new BeyBlade(build.bitChip, build.over, build.blade, build.assist, build.rachet, build.bit), build);
        }
        return Object.assign(new BeyBlade(build.bitChip, build.over, build.blade, build.assist, build.rachet, build.bit), build);
    }

    /**
     * Does a build snapshot match the given parts filter? 
     * null/undefined on a filter field = wildcard.
     * @param {object} bey
     * @param {{bitChip?: *, over?: *, blade?: *, assist?: *, rachet?: *, bit?: *}} parts
     * @returns {boolean}
     */
    static matchesPartsFilter(bey, parts) {
        if (!bey) {
            return false;
        }
        if (parts.blade != null && bey.blade != parts.blade) {
            return false;
        }
        if (parts.rachet != null && bey.rachet != parts.rachet) {
            return false;
        }
        if (parts.bit != null && bey.bit != parts.bit) {
            return false;
        }
        var bladeForSystem = parts.blade != null ? parts.blade : bey.blade;
        var system = bladeForSystem != null && allBlades[bladeForSystem]
            ? allBlades[bladeForSystem].system
            : null;
        if (parts.blade == null || system === "CX") {
            if (parts.bitChip != null && bey.bitChip != parts.bitChip) {
                return false;
            }
            if (parts.assist != null && bey.assist != parts.assist) {
                return false;
            }
        }
        if (parts.blade == null || system === "CX2") {
            if (parts.bitChip != null && bey.bitChip != parts.bitChip) {
                return false;
            }
            if (parts.assist != null && bey.assist != parts.assist) {
                return false;
            }
            if (parts.over != null && bey.over != parts.over) {
                return false;
            }
        }
        return true;
    }

}