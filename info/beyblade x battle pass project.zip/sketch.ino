void setup() {
pinMode(12, INPUT_PULLUP);
pinMode(9, OUTPUT);
pinMode(7, OUTPUT);
pinMode(5, OUTPUT);
}

void loop() {
  if (digitalRead(12) == LOW){
    digitalWrite(5, LOW);
    digitalWrite(7, HIGH);
  }
  else {
   digitalWrite(7, LOW);
   digitalWrite(5, HIGH);
  }
}